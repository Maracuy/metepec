<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form action="subirmysql.php" method="POST">
    <input type="text" placeholder="CODE" id="CODE" name="CODE">
    <input type="text" placeholder="ST" id="ST" name="ST">
    <input type="text" placeholder="FECHA" id="FECHA" name="FECHA">
    <input type="text" placeholder="REGISTRA" id="REGISTRA" name="REGISTRA">
    <input type="text" placeholder="ORIG" id="ORIG" name="ORIG">
    <input type="text" placeholder="GEST" id="GEST" name="GEST">
    <input type="text" placeholder="MEDIO" id="MEDIO" name="MEDIO">
    <input type="text" placeholder="ATN" id="ATN" name="ATN">
    <input type="text" placeholder="SOLICITUD" id="SOLICITUD" name="SOLICITUD">
    <input type="text" placeholder="PFB" id="PFB" name="PFB">
    <input type="text" placeholder="BENEFICIARIO" id="BENEFICIARIO" name="BENEFICIARIO">
    <input type="text" placeholder="PGF" id="PGF" name="PGF">
    <input type="text" placeholder="GESTOR" id="GESTOR" name="GESTOR">
    <input type="text" placeholder="CONTACTO" id="CONTACTO" name="CONTACTO">
    <input type="text" placeholder="UBICACIÓN" id="UBICACIÓN" name="UBICACIÓN">
    <input type="text" placeholder="PRGM" id="PRGM" name="PRGM">
    <input type="text" placeholder="DEPT" id="DEPT" name="DEPT">
    <input type="text" placeholder="P_RSP" id="P_RSP" name="P_RSP">
    <input type="text" placeholder="ACP" id="ACP" name="ACP">
    <input type="text" placeholder="TIPO" id="TIPO" name="TIPO">
    <input type="text" placeholder="REC_DCS" id="REC_DCS" name="REC_DCS">
    <input type="text" placeholder="TERM" id="TERM" name="TERM">
    <input type="text" placeholder="LIST" id="LIST" name="LIST">
    <input type="text" placeholder="ENV" id="ENV" name="ENV">
    <input type="text" placeholder="RESPUESTA" id="RESPUESTA" name="RESPUESTA">
    <input type="text" placeholder="SL_VST" id="SL_VST" name="SL_VST">
    <input type="text" placeholder="FECHA_V" id="FECHA_V" name="FECHA_V">
    <input type="text" placeholder="GEN_D" id="GEN_D" name="GEN_D">
    <input type="text" placeholder="ENV_D" id="ENV_D" name="ENV_D">
    <input type="text" placeholder="DOC" id="DOC" name="DOC">
    <input type="text" placeholder="PROGRESO" id="PROGRESO" name="PROGRESO">
    <input type="text" placeholder="ST_FN" id="ST_FN" name="ST_FN">
    
    <input type="submit" value="Enviar este formulario" formmethod="POST"/>
</form>
</body>
</html>